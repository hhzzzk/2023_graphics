#pragma once

enum ShadingType { kSmooth, kFlat };
